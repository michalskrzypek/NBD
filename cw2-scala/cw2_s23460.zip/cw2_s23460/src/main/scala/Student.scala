trait Student extends Osoba {
  override val podatek: Int = 0
}
