trait Nauczyciel extends Pracownik {
  override val podatek: Int = 10
}
