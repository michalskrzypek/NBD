case class Osoba(imie: String, nazwisko: String) {
  val podatek = 0
}
