trait Pracownik extends Osoba {
  override val podatek: Int = 20
  var pensja: Double = 0
}
